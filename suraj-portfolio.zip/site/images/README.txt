Put project screenshots here (for example qr-reader.png) and replace the matching <svg> in index.html with:
<img src="images/qr-reader.png" alt="QR Code Reader screenshot">
