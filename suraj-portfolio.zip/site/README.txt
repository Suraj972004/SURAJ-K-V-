SURAJ K.V. PORTFOLIO
====================
Files
  index.html            Page content
  style.css             Design and animations
  script.js             Interactions
  Suraj_K_V_Resume.pdf  Used by the Download resume buttons
  images/               Optional project screenshots

Preview locally: double-click index.html.

Publish free on GitHub Pages
  1. Create a public repository named Suraj972004.github.io
  2. Add file > Upload files: upload everything in this folder (keep file names), then Commit.
  3. Settings > Pages > Deploy from a branch > main / (root) > Save.
  4. Your site appears at https://suraj972004.github.io in a minute or two.

Publish free on Netlify
  Go to app.netlify.com/drop and drag this whole folder onto the page.
