(function(){
  var $=function(s,c){return (c||document).querySelector(s)},$$=function(s,c){return Array.prototype.slice.call((c||document).querySelectorAll(s))};
  var reduce=matchMedia('(prefers-reduced-motion: reduce)').matches,fine=matchMedia('(pointer:fine)').matches;
  $('#yr').textContent=new Date().getFullYear();

  var menu=$('#menu'),links=$('#links');
  menu.onclick=function(){var o=links.classList.toggle('open');menu.setAttribute('aria-expanded',o)};
  $$('#links a').forEach(function(a){a.onclick=function(){links.classList.remove('open');menu.setAttribute('aria-expanded','false')}});

  // scroll progress
  var bar=$('#progress');
  addEventListener('scroll',function(){var h=document.documentElement;bar.style.width=(h.scrollTop/(h.scrollHeight-h.clientHeight)*100)+'%'},{passive:true});

  // cursor spotlight
  if(fine&&!reduce)addEventListener('pointermove',function(e){document.body.style.setProperty('--mx',e.clientX+'px');document.body.style.setProperty('--my',e.clientY+'px')});
  $$('.panel').forEach(function(p){p.addEventListener('pointermove',function(e){var r=p.getBoundingClientRect();p.style.setProperty('--px',(e.clientX-r.left)+'px');p.style.setProperty('--py',(e.clientY-r.top)+'px')})});

  // project card tilt
  if(fine&&!reduce)$$('.tilt').forEach(function(el){
    el.addEventListener('pointermove',function(e){var r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;el.style.transform='rotateY('+x*10+'deg) rotateX('+(-y*10)+'deg) translateY(-4px)'});
    el.addEventListener('pointerleave',function(){el.style.transform=''});
  });

  // rotating role (typewriter)
  var roles=['MBA graduate in finance','Business analyst in the making','Python & web developer','Data-driven problem solver'],ri=0,ci=0,del=false,roleEl=$('#role');
  function type(){
    var w=roles[ri];
    if(reduce){roleEl.textContent=w;return}
    ci+=del?-1:1;roleEl.textContent=w.slice(0,ci);
    var t=del?35:70;
    if(!del&&ci===w.length){del=true;t=1600}else if(del&&ci===0){del=false;ri=(ri+1)%roles.length;t=350}
    setTimeout(type,t);
  }
  type();

  // terminal typing
  var lines=[
    [['c','// profile']],
    [['k','const '],['','suraj = {']],
    [['','  role: '],['s','"MBA, Finance"'],['','},']],
    [['','  languages: ['],['s','"Python"'],['','", "'],['s','"Java"'],['','],']],
    [['','  web: ['],['s','"HTML"'],['','", "'],['s','"CSS"'],['','", "'],['s','"JS"'],['','],']],
    [['','  focus: '],['s','"analytics"'],['','},']],
    [['','  available: '],['k','true']],
    [['','};']]
  ];
  // simplify punctuation so output stays valid-looking
  lines[2]=[['','  role: '],['s','"MBA, Finance"'],['',',']];
  lines[3]=[['','  languages: ['],['s','"Python"'],['',', '],['s','"Java"'],['','],']];
  lines[4]=[['','  web: ['],['s','"HTML"'],['',', '],['s','"CSS"'],['',', '],['s','"JS"'],['','],']];
  lines[5]=[['','  focus: '],['s','"finance analytics"'],['',',']];
  var term=$('#term');
  function esc(s){return s.replace(/&/g,'&amp;').replace(/</g,'&lt;')}
  function renderTerm(li,chars){
    var out='';
    for(var i=0;i<=li&&i<lines.length;i++){
      var left=i<li?Infinity:chars;
      lines[i].forEach(function(seg){if(left<=0)return;var t=seg[1].slice(0,left);left-=seg[1].length;out+=seg[0]?'<span class="'+seg[0]+'">'+esc(t)+'</span>':esc(t)});
      out+='\n';
    }
    term.innerHTML=out+(li<lines.length?'<i class="caret"></i>':'');
  }
  (function runTerm(){
    if(reduce){renderTerm(lines.length,0);return}
    var li=0,ch=0;
    (function tick(){
      if(li>=lines.length){renderTerm(lines.length,0);return}
      var len=lines[li].reduce(function(a,s){return a+s[1].length},0);
      ch+=2;renderTerm(li,ch);
      if(ch>=len){li++;ch=0;setTimeout(tick,140)}else setTimeout(tick,28);
    })();
  })();

  // marquee
  var items=['HTML','CSS','JavaScript','Python','Java','Git','GitHub','Excel modelling','Financial analysis','Data analytics','Tally ERP 9','Digital marketing'];
  var h='';for(var k=0;k<2;k++)items.forEach(function(t){h+='<span>'+t+'</span>'});
  $('#track').innerHTML=h;

  // counters
  function count(el){
    var to=parseFloat(el.dataset.to),dec=+el.dataset.dec||0;
    if(reduce){el.textContent=to.toFixed(dec);return}
    var t0=null;(function s(t){if(!t0)t0=t;var p=Math.min((t-t0)/1500,1);el.textContent=(to*(1-Math.pow(1-p,3))).toFixed(dec);if(p<1)requestAnimationFrame(s)})(performance.now());
  }
  var io=new IntersectionObserver(function(es){es.forEach(function(e){
    if(e.isIntersecting){e.target.classList.add('in');$$('[data-to]',e.target).forEach(count);io.unobserve(e.target)}
  })},{threshold:.12});
  $$('.reveal').forEach(function(el){io.observe(el)});

  // active nav
  var spy=new IntersectionObserver(function(es){es.forEach(function(e){
    if(e.isIntersecting)$$('#links a').forEach(function(a){a.classList.toggle('active',a.getAttribute('href')==='#'+e.target.id)})
  })},{rootMargin:'-45% 0px -50% 0px'});
  $$('main section[id]').forEach(function(s){spy.observe(s)});

  // QR illustration
  var n=21,c=6,ox=(320-n*c)/2,oy=(180-n*c)/2,seed=7,out='';
  function rnd(){seed=(seed*9301+49297)%233280;return seed/233280}
  function fin(x,y){return '<rect x="'+(ox+x*c)+'" y="'+(oy+y*c)+'" width="'+7*c+'" height="'+7*c+'" fill="#D4AF37"/><rect x="'+(ox+(x+1)*c)+'" y="'+(oy+(y+1)*c)+'" width="'+5*c+'" height="'+5*c+'" fill="#0B0B0C"/><rect x="'+(ox+(x+2)*c)+'" y="'+(oy+(y+2)*c)+'" width="'+3*c+'" height="'+3*c+'" fill="#D4AF37"/>'}
  for(var i=0;i<n;i++)for(var j=0;j<n;j++){
    var inF=(i<8&&j<8)||(i>12&&j<8)||(i<8&&j>12);
    if(!inF&&rnd()>.5)out+='<rect x="'+(ox+i*c)+'" y="'+(oy+j*c)+'" width="'+c+'" height="'+c+'" fill="#F4F1E8" opacity=".85"/>';
  }
  out+=fin(0,0)+fin(14,0)+fin(0,14);
  out+='<rect x="'+(ox-12)+'" y="'+oy+'" width="'+(n*c+24)+'" height="3" rx="1.5" fill="#F6DE8D"><animate attributeName="y" values="'+oy+';'+(oy+n*c)+';'+oy+'" dur="3s" repeatCount="indefinite"/></rect>';
  $('#qr').innerHTML=out;

  // contact form -> email app
  $('#form').addEventListener('submit',function(e){
    e.preventDefault();
    var f=e.target,nm=f.name.value.trim(),em=f.email.value.trim(),m=f.msg.value.trim(),st=$('#msg');
    if(!nm||!/^\S+@\S+\.\S+$/.test(em)||!m){st.style.color='#F28B82';st.textContent='Enter your name, a valid email and a message.';return}
    st.style.color='';st.textContent='Opening your email app…';
    location.href='mailto:surajkv753@gmail.com?subject='+encodeURIComponent('Portfolio message from '+nm)+'&body='+encodeURIComponent('From: '+nm+' ('+em+')\n\n'+m);
  });
})();
